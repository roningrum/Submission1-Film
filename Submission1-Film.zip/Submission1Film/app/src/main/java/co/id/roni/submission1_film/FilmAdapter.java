package co.id.roni.submission1_film;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class FilmAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Film> films;
    private String[] dataNameFilm;
    private String[] dataOverviewFilm;
    private String[] dataUserScoreFilm;
    private TypedArray dataPhotoFilm;

    public FilmAdapter(Context context) {
        this.context = context;
        films = new ArrayList<>();
        getDataForDetailFilm();
    }

    public void setFilms(ArrayList<Film> films) {
        this.films = films;
    }

    @Override
    public int getCount() {
        return films.size();
    }

    @Override
    public Object getItem(int i) {
        return films.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_film_list, viewGroup, false);
            viewHolder = new ViewHolder(view);
            view.setTag(viewHolder);

        }
        else{
           viewHolder = (ViewHolder)view.getTag();
        }
        viewHolder.btnSeeDetails.setTag(i);

        Film film = (Film) getItem(i);
        viewHolder.bind(film);
        return view;
    }

    private void getDataForDetailFilm(){
        dataNameFilm = context.getResources().getStringArray(R.array.data_name_film);
        dataOverviewFilm = context.getResources().getStringArray(R.array.data_overview_film);
        dataUserScoreFilm = context.getResources().getStringArray(R.array.data_user_score);
        dataPhotoFilm = context.getResources().obtainTypedArray(R.array.data_photo_film);
    }
    private class ViewHolder implements View.OnClickListener{
        private TextView txtNameFilm;
        private TextView txtOverviewFilm;
        private ImageView imgPhotoFilm;
        private Button btnSeeDetails;

        ViewHolder(View view) {
            txtNameFilm = view.findViewById(R.id.txt_name_film);
            txtOverviewFilm = view.findViewById(R.id.txt_overview_film);
            imgPhotoFilm = view.findViewById(R.id.img_film);
            btnSeeDetails = view.findViewById(R.id.btn_see_detail);

        }

        void bind(Film film) {
            txtNameFilm.setText(film.getNameFilm());
            txtOverviewFilm.setText(film.getOverviewFilm());
            imgPhotoFilm.setImageResource(film.getPhotoFilm());
            btnSeeDetails.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            if(view.getId() == R.id.btn_see_detail){
                int position = (Integer) view.getTag();
                Film film = new Film();
                film.setNameFilm(dataNameFilm[position]);
                film.setOverviewFilm(dataOverviewFilm[position]);
                film.setAudienceScoreFilm(dataUserScoreFilm[position]);
                film.setPhotoFilm(dataPhotoFilm.getResourceId(position, -1));

                Intent filmInfoDetail = new Intent(context, FilmDetailActivity.class);
                filmInfoDetail.putExtra(FilmDetailActivity.EXTRA_FILMS, film);
                context.startActivity(filmInfoDetail);

            }
        }
    }
}
