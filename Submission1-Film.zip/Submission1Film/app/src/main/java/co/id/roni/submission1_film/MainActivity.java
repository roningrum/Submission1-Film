package co.id.roni.submission1_film;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String[] dataNameFilm;
    private String[] dataOverViewFilm;
    private TypedArray dataPhotoFilm;
    private FilmAdapter filmAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = findViewById(R.id.lv_film);

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Movie Db List");
        }

        filmAdapter = new FilmAdapter(this);
        listView.setAdapter(filmAdapter);
        prepareItemFilm();
        addItemFilm();
    }

    private void prepareItemFilm() {
        dataNameFilm = getResources().getStringArray(R.array.data_name_film);
        dataOverViewFilm = getResources().getStringArray(R.array.data_overview_film);
        dataPhotoFilm = getResources().obtainTypedArray(R.array.data_photo_film);
    }

    private void addItemFilm() {
        ArrayList<Film> films = new ArrayList<>();
        for (int i = 0; i < dataNameFilm.length; i++) {
            Film film = new Film();
            film.setPhotoFilm(dataPhotoFilm.getResourceId(i, -1));
            film.setNameFilm(dataNameFilm[i]);
            film.setOverviewFilm(dataOverViewFilm[i]);
            films.add(film);
        }
        filmAdapter.setFilms(films);
    }


}
